#!/bin/bash
#
# Variables to be used for background styling.

# app variables

jwt_secret=3123123213123
jwt_refresh_secret=75756756756

deploy_password=ZdGXaUHeZ3EKzU=

#mysql_root_password=$(openssl rand -base64 32)

db_pass=ZdG387FhYsm0olSm097541HMSdS

db_user=root
db_name=whaticket

deploy_email=deploy@whaticket.com
